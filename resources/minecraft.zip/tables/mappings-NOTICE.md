# 第三方数据声明

物品、群系、旗帜图案和实体的生成器使用以下上游的名称、编号和对应关系。各主题的归档记录实际使用的文件和提交。

## GeyserMC/mappings

来源：https://github.com/GeyserMC/mappings
使用文件：`items.json`、`biomes.json`
版本和提交由发布资源的版本锁指定，并保存在生成归档的 sources 字段。

```text
The MIT License

Copyright (c) 2019-2020 GeyserMC. http://geysermc.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

## pmmp/BedrockData

来源：https://github.com/pmmp/BedrockData
使用文件：`biome_id_map.json`、`banner_patterns.json`、`entity_id_map.json`
版本和提交由发布资源的版本锁指定，并保存在生成归档的 sources 字段。

该仓库以 CC0-1.0 发布，不要求署名；这里保留来源与版本以便复查。
